export default class HeroPartial {
  constructor(config) {
    this.config = config || {}

    console.log('Hero welcomes you');
  }
}
