export default class FooterPartial {
  constructor(config) {
    this.config = config || {}

    console.log('Footer welcomes you');
  }
}
