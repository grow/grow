export default class HeaderPartial {
  constructor(config) {
    this.config = config || {}

    console.log('Header welcomes you');
  }
}
