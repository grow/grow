import FooterPartial from '../../../partials/footer/footer';
import HeaderPartial from '../../../partials/header/header';

new HeaderPartial({});
new FooterPartial({});
