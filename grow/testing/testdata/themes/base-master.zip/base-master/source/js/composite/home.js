import HeroPartial from '../../../partials/hero/hero';

new HeroPartial({});
